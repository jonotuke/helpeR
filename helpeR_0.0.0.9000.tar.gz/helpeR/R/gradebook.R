#' Example gradebook
#'
#' An example gradebook
#' Report ...
#'
#' @format ## `gradebook`
#' A data frame with 15 rows and 16 columns:
#' \describe{
#'   \item{student_id}{UoA number}
#'   \item{myuni_total}{Total from MyUni}
#' }
#' @source SC2024
"gradebook"
